CIBC Loan Eligibility Predictor 

This project takes the details from the user and informs them about thier loan elgibility

The project was compiled with python 3.11 and has the following important files 

1.requirments.txt - details of the packages used 
2.Graded_project_3_solution.ipynd - steps taken to generate the model. 
3.app.py - is the actual application which needs to be run 
4.Screenshot.docx - screenshots of all the html pages. 

